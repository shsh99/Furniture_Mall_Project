import { useState } from "react";

import { Container, Content, ClosedSideBar, OpenSideBar } from "./../Styles";
import { MdSettings } from "react-icons/md";
import { RiLogoutCircleRLine } from "react-icons/ri";
import { CiHeart } from "react-icons/ci";
import { CiMenuBurger } from "react-icons/ci";

import { IoNotificationsSharp } from "react-icons/io5";
import { BsArrowRight, BsArrowLeft } from "react-icons/bs";
import { DiReact } from "react-icons/di";
import { BsBackspace } from "react-icons/bs";
import { RxHamburgerMenu } from "react-icons/rx";



import logoImg from "../../assets/images/4.png";
// import userImg from "../../assets/images/post-1.jpg";

// type OnSubMenuClickHandler = () => void;


// interface SideBarProps {
//   onSubMenuClick?: OnSubMenuClickHandler;
// }

export function AddSide() {
    const [sideBar, setSideBar] = useState(false);
    const [showSubMenu, setShowSubMenu] = useState(false);
    const [showSubMenu2, setShowSubMenu2] = useState(false);
    const [showSubMenu3, setShowSubMenu3] = useState(false);

    function handleChangeSideBar() {
        setSideBar((prevState) => !prevState);
        setShowSubMenu(false);
        setShowSubMenu2(false);
        setShowSubMenu3(false);
    }

    function handleSubMenuClick() {
        setShowSubMenu((prevState) => !prevState);
        setShowSubMenu2(false);
        setShowSubMenu3(false);
    }

    function handleSubMenuClick2() {
        setShowSubMenu2((prevState) => !prevState);
        setShowSubMenu(false);
        setShowSubMenu3(false);
    }

    function handleSubMenuClick3() {
        setShowSubMenu3((prevState) => !prevState);
        setShowSubMenu(false);
        setShowSubMenu2(false);
    }
    return (
        <Container>
            <Content>
                {!sideBar ? (
                    <ClosedSideBar>
                        <nav>
                            <button onClick={handleChangeSideBar} style={{ color: "#002" }} className="fixedButton">
                                상세보기
                            </button>

                        </nav>

                    </ClosedSideBar>
                ) : (
                    <OpenSideBar>
                        <section className="sideBack">
                            <nav>
                                <span>

                                    <ul>
                                        <h1>Menu</h1>
                                    </ul>
                                </span>

                                <div className="sidebar">

                                </div>


                                {/* Icones principais do app */}

                                <ul className="side-text">
                                    <a onClick={handleSubMenuClick} title="Alguma coisa">
                                        <p>상품평</p>
                                    </a>
                                    {/* 열렸을 때 */}

                                    {/* 안 열렸을때 */}
                                    {/* {!showSubMenu && ( */}
                                    <>
                                        <a onClick={handleSubMenuClick2} title="Alguma coisa">
                                            <p>공간별 인테리어</p>
                                        </a>


                                        <a onClick={handleSubMenuClick3} title="Alguma coisa">
                                            <p>고객센터</p>
                                        </a>

                                    </>
                                    {/* )} */}
                                </ul>
                            </nav>
                            <div>
                                <ul>
                                    <a href="/like-page">
                                        <p>
                                            <CiHeart />
                                            &nbsp; &nbsp;찜
                                        </p>
                                    </a>
                                    <a href="/">
                                        <p>
                                            {" "}
                                            <MdSettings />
                                            &nbsp; &nbsp; 설정
                                        </p>
                                    </a>
                                    <a href="/">
                                        <p>
                                            <RiLogoutCircleRLine />
                                            &nbsp; &nbsp; 나가기{" "}
                                        </p>
                                    </a>
                                </ul>

                                <span>
                                    {/* <img src={userImg} alt="Eu" /> */}
                                    {/* 요거 지우면 안됨 */}
                                    <p>Eco Furniture Mall Web Developeraaaaaaaaaaaaaaaaaaaaaaaaaaaaa</p>
                                </span>
                            </div>
                        </section>
                        <aside onClick={handleChangeSideBar} />
                    </OpenSideBar>
                )}
            </Content>
        </Container>
    );
}
